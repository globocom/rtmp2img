Requirements
------------

OS requirements:
* ffmpeg
* rtmpdump

Python requirements:
Everything listed in requirements.txt


Usage
-----
$ python rtmp2img/cli.py --output --log --url --rtmpdump --ffmpeg
